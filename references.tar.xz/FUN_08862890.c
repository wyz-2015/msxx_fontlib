
undefined1 FUN_08862890(void)

{
	return DAT_08b047be;
}
