
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

uint FUN_08862338(uint param_1)

{
	uint uVar1;
	uint uVar2;
	ushort* puVar3;
	uint uVar4;

	uVar1 = param_1 & 0xffff;
	uVar4 = 0;
	puVar3 = &DAT_0888b5dc;
	do {
		if (uVar1 <= *puVar3)
			break;
		uVar4 = uVar4 + 1;
		puVar3 = puVar3 + 1;
	} while (uVar4 < 6);
	uVar4 = uVar4 & 0xffff;
	if (uVar4 == 0) {
		uVar2 = 0;
	} else {
		uVar2 = (uint) * (ushort*)((int)&PTR_caseD_6_0888b5d8 + uVar4 * 2 + 2);
	}
	uVar2 = uVar1 - uVar2 & 0xffff;
	if (uVar4 == 5) {
		uVar2 = uVar2 + DAT_0888b5dc + ((uint)DAT_0888b5e2 - (uint)DAT_0888b5e0 & 0xffff) & 0xffff;
	} else if (uVar4 == 3) {
		uVar2 = uVar2 + DAT_0888b5dc & 0xffff;
	} else if (uVar4 != 0) {
		if (_DAT_08b047d0 == 0) {
			uVar4 = 0;
		} else {
			if (_DAT_08b047ca != 0) {
				uVar4 = 0;
				do {
					if (uVar1 == *(ushort*)(_DAT_08b047d0 + uVar4 * 2))
						goto LAB_0886248c;
					uVar4 = uVar4 + 1 & 0xffff;
				} while (uVar4 < _DAT_08b047ca);
			}
			uVar4 = 0;
		}
	LAB_0886248c:
		uVar2 = ((uint)DAT_0888b5e6 - (uint)DAT_0888b5e4 & 0xffff) + ((uint)DAT_0888b5e2 - (uint)DAT_0888b5e0 & 0xffff) + uVar4 + DAT_0888b5dc & 0xffff;
	}
	return uVar2;
}
