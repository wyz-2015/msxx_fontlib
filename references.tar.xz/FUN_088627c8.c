
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

ushort* FUN_088627c8(uint param_1)

{
	ushort* puVar1;
	uint uVar2;

	if ((_DAT_08b047cc == 0) || (_DAT_08b047c0 == 0)) {
		puVar1 = (ushort*)0x0;
	} else {
		uVar2 = FUN_08862338(param_1);
		if ((uVar2 & 0xffff) < (uint)_DAT_08b047c8) {
			uVar2 = (uint) * (ushort*)(_DAT_08b047cc + (uVar2 & 0xffff) * 2);
			if (uVar2 < _DAT_08b047bc) {
				puVar1 = (ushort*)(_DAT_08b047c0 + uVar2 * 0x14);
			} else {
				puVar1 = (ushort*)0x0;
			}
			if (puVar1 == (ushort*)0x0) {
				puVar1 = (ushort*)0x0;
			} else if ((uint)*puVar1 != (param_1 & 0xffff)) {
				puVar1 = (ushort*)0x0;
			}
		} else {
			puVar1 = (ushort*)0x0;
		}
	}
	return puVar1;
}
