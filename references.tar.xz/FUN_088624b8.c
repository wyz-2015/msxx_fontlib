
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_088624b8(ushort* param_1, undefined4 param_2, undefined4 param_3, undefined4 param_4)

{
	uint* puVar1;
	uint uVar2;
	uint* puVar3;
	uint uVar4;
	uint uVar5;
	int iVar6;
	int iVar7;
	ushort* puVar8;
	byte* pbVar9;

	if (param_1 != (ushort*)0x0) {
		FUN_0880ec84(s_Begin_read_font_lib______________08895898, param_2, param_3, param_4);
		_DAT_08b047c8 = *param_1;
		uVar2 = (uint)_DAT_08b047c8;
		puVar8 = param_1 + 1;
		uVar4 = uVar2 * 2;
		_DAT_08b047cc = FUN_08861ec8(uVar4, 8, param_3, param_4);
		FUN_0880d31c(_DAT_08b047cc, (undefined4*)puVar8, uVar4);
		puVar8 = puVar8 + uVar2;
		_DAT_08b047ca = *puVar8;
		puVar8 = puVar8 + 1;
		uVar2 = (uint)_DAT_08b047ca;
		uVar5 = uVar2 * 2;
		_DAT_08b047d0 = FUN_08861ec8(uVar5, 8, uVar4, param_4);
		FUN_0880d31c(_DAT_08b047d0, (undefined4*)puVar8, uVar5);
		puVar8 = puVar8 + uVar2;
		_DAT_08b047bc = *puVar8;
		puVar8 = puVar8 + 1;
		uVar2 = (uint)_DAT_08b047bc;
		uVar4 = uVar2 * 0x14;
		_DAT_08b047c0 = FUN_08861ec8(uVar4, 8, uVar5, param_4);
		FUN_0880d31c(_DAT_08b047c0, (undefined4*)puVar8, uVar4);
		DAT_08b047be = (byte)puVar8[uVar2 * 10];
		pbVar9 = (byte*)((int)(puVar8 + uVar2 * 10) + 1);
		uVar2 = (uint)DAT_08b047be;
		FUN_0880ec84(s__d_characters_and__d_pages_Textu_088958d0, (uint)_DAT_08b047bc, uVar2, param_4);
		uVar4 = (uint)DAT_08b047be * 0x10;
		_DAT_08b047c4 = FUN_08861ec8(uVar4, 8, uVar2, param_4);
		uVar2 = uVar4;
		FUN_0880d31c(_DAT_08b047c4, (undefined4*)pbVar9, uVar4);
		pbVar9 = pbVar9 + uVar4;
		iVar7 = 0;
		if (DAT_08b047be != 0) {
			iVar6 = 0;
			do {
				puVar1 = _DAT_08b047c4;
				uVar4 = *(uint*)((int)_DAT_08b047c4 + iVar6 + 8);
				puVar3 = FUN_08861ec8(uVar4, 0x10, uVar2, param_4);
				*(uint**)((int)puVar1 + iVar6 + 0xc) = puVar3;
				uVar2 = uVar4;
				FUN_0880d31c(puVar3, (undefined4*)pbVar9, uVar4);
				iVar7 = iVar7 + 1;
				pbVar9 = pbVar9 + uVar4;
				iVar6 = iVar6 + 0x10;
			} while (iVar7 < (int)(uint)DAT_08b047be);
		}
		iVar7 = (int)pbVar9 - (int)param_1;
		FUN_0880ec84(s__d_bytes_read_088958f8, iVar7, uVar2, param_4);
		FUN_0880ec84(s_End_read_font_lib________________08895908, iVar7, uVar2, param_4);
	}
	return;
}
