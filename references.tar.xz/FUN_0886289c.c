
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

int FUN_0886289c(uint param_1)

{
	int iVar1;

	if (param_1 < DAT_08b047be) {
		iVar1 = _DAT_08b047c4 + param_1 * 0x10;
	} else {
		iVar1 = 0;
	}
	return iVar1;
}
