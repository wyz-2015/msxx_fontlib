
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

int FUN_08862b34(ushort* param_1, uint* param_2, uint* param_3, uint* param_4)

{
	ushort uVar1;
	int iVar2;
	uint uVar3;
	uint* puVar4;
	uint* puVar5;
	uint* puVar6;
	uint uVar7;
	uint uVar8;
	float fVar9;
	float fVar10;
	int local_4c;
	int local_48;
	int local_24;
	uint local_18;
	int local_14;
	int local_10;
	undefined2 local_c;
	undefined2 local_a;
	undefined2 local_8;
	undefined2 local_6;
	uint local_4;

	if (_DAT_08b047a8 != 0) {
		if (param_1 == (ushort*)0x0) {
			return 0;
		}
		if ((((param_2 != (uint*)0x0) && (param_3 != (uint*)0x0)) && (param_4 != (uint*)0x0)) && (local_4 = param_2[3], local_4 != 0)) {
			uVar3 = *param_2;
			local_18 = 0;
			local_c = (undefined2)uVar3;
			local_6 = 0;
			local_8 = (undefined2)(uVar3 >> 1);
			uVar8 = *param_3;
			uVar3 = uVar3 << 6;
			uVar7 = *param_4;
			if (uVar3 <= uVar8) {
				uVar8 = 0;
			}
			if (uVar3 <= uVar7) {
				uVar7 = 0x475;
			}
			if ((int)uVar3 < 0) {
				fVar9 = (float)(uVar3 >> 1) + (float)(uVar3 >> 1);
			} else {
				fVar9 = (float)(int)uVar3;
			}
			fVar9 = 1.0 / fVar9;
			puVar4 = param_3;
			puVar5 = param_4;
			local_a = local_c;
			FUN_0880ec84(s_Begin_make_texture_for_08895a3c, param_2, param_3, param_4);
			if (*param_1 != 0) {
				uVar1 = *param_1;
				while (puVar6 = (uint*)(uint)uVar1, puVar6 != (uint*)0x0) {
					iVar2 = FUN_08883c78();
					if (iVar2 != 0) {
						return 0;
					}
					if (uVar3 < uVar8 + local_24) {
						uVar8 = 0;
						uVar7 = uVar7 + 0x575;
					}
					local_14 = uVar8 + local_4c * 0x40;
					local_10 = uVar7 + local_48 * -0x40;
					puVar4 = &local_18;
					iVar2 = FUN_08883c68();
					if (iVar2 != 0) {
						return iVar2;
					}
					fVar10 = (float)(int)uVar8;
					uVar8 = uVar8 + local_24 + 0x40;
					*(float*)(param_1 + 2) = fVar10 * fVar9;
					*(float*)(param_1 + 4) = fVar9 * (float)(int)uVar8;
					*(float*)(param_1 + 6) = fVar9 * (float)(int)(uVar7 - 0x3f5);
					*(float*)(param_1 + 8) = fVar9 * (float)(int)(uVar7 + 0x140);
					*(undefined1*)(param_1 + 1) = DAT_08b047be;
					param_1 = param_1 + 10;
					param_2 = puVar6;
					if (*param_1 == 0)
						break;
					uVar1 = *param_1;
				}
			}
			*param_3 = uVar8;
			*param_4 = uVar7;
			FUN_0880ec84(s_End_make_texture_08895a54, param_2, puVar4, puVar5);
			return 1;
		}
	}
	return 0;
}
