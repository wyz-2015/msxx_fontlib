
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_088626c0(undefined4 param_1, undefined4 param_2, undefined4 param_3, undefined4 param_4)

{
	int iVar1;
	int iVar2;
	int iVar3;

	if (_DAT_08b047cc != (undefined4*)0x0) {
		FUN_08861f50(_DAT_08b047cc, param_2, param_3, param_4);
		_DAT_08b047cc = (undefined4*)0x0;
	}
	if (_DAT_08b047d0 != (undefined4*)0x0) {
		FUN_08861f50(_DAT_08b047d0, param_2, param_3, param_4);
		_DAT_08b047d0 = (undefined4*)0x0;
	}
	if (_DAT_08b047c0 != (undefined4*)0x0) {
		FUN_08861f50(_DAT_08b047c0, param_2, param_3, param_4);
		_DAT_08b047c0 = (undefined4*)0x0;
	}
	if (_DAT_08b047c4 != (undefined4*)0x0) {
		iVar2 = 0;
		if (DAT_08b047be != 0) {
			iVar1 = 0;
			do {
				iVar3 = (int)_DAT_08b047c4 + iVar1;
				if ((iVar3 != 0) && (*(undefined4**)(iVar3 + 0xc) != (undefined4*)0x0)) {
					FUN_08861f50(*(undefined4**)(iVar3 + 0xc), param_2, param_3, param_4);
					*(undefined4*)(iVar3 + 0xc) = 0;
				}
				iVar2 = iVar2 + 1;
				iVar1 = iVar1 + 0x10;
			} while (iVar2 < (int)(uint)DAT_08b047be);
		}
		FUN_08861f50(_DAT_08b047c4, param_2, param_3, param_4);
		_DAT_08b047c4 = (undefined4*)0x0;
	}
	return;
}
