
short* FUN_08883654(short param_1)

{
	uint uVar1;
	short* psVar2;
	int iVar3;

	uVar1 = (uint)DAT_088eae60;
	if ((uVar1 != 0) && (iVar3 = 0, psVar2 = DAT_088eae64, uVar1 != 0)) {
		do {
			if (*psVar2 == param_1) {
				return psVar2;
			}
			iVar3 = iVar3 + 1;
			psVar2 = psVar2 + 10;
		} while (iVar3 < (int)uVar1);
	}
	return (short*)0x0;
}
